try:
    import pygame, time, random, os, platform
    from pygame.locals import *
except ImportError:
    print("Erreur d'importation des modules supplémentaires ")
except Exception as error:
    print(f"[ERROR] : {error}")
else:
    def conditionsWin():
        # Gagner sur les lignes diagonales
        if matrix[0][0] == "X" and matrix[1][1] == "X" and matrix[2][2] == "X": return "Xwin"
        if matrix[0][0] == "O" and matrix[1][1] == "O" and matrix[2][2] == "O": return "Owin"
        if matrix[0][2] == "X" and matrix[1][1] == "X" and matrix[2][0] == "X": return "Xwin"
        if matrix[0][2] == "O" and matrix[1][1] == "O" and matrix[2][0] == "O": return "Owin"

        # Gagner sur les lignes verticales
        if matrix[0][0] == "X" and matrix[1][0] == "X" and matrix[2][0] == "X": return "Xwin"
        if matrix[0][1] == "X" and matrix[1][1] == "X" and matrix[2][1] == "X": return "Xwin"
        if matrix[0][2] == "X" and matrix[1][2] == "X" and matrix[2][2] == "X": return "Xwin"
        if matrix[0][0] == "O" and matrix[1][0] == "O" and matrix[2][0] == "O": return "Owin"
        if matrix[0][1] == "O" and matrix[1][1] == "O" and matrix[2][1] == "O": return "Owin"
        if matrix[0][2] == "O" and matrix[1][2] == "O" and matrix[2][2] == "O": return "Owin"

        # Gagner sur les lignes horizontales
        if matrix[0][0] == "X" and matrix[0][1] == "X" and matrix[0][2] == "X": return "Xwin"
        if matrix[1][0] == "X" and matrix[1][1] == "X" and matrix[1][2] == "X": return "Xwin"
        if matrix[2][0] == "X" and matrix[2][1] == "X" and matrix[2][2] == "X": return "Xwin"
        if matrix[0][0] == "O" and matrix[0][1] == "O" and matrix[0][2] == "O": return "Owin"
        if matrix[1][0] == "O" and matrix[1][1] == "O" and matrix[1][2] == "O": return "Owin"
        if matrix[2][0] == "O" and matrix[2][1] == "O" and matrix[2][2] == "O": return "Owin"

        # Quand il y a match nul
        if matrix[0][0] != "" and matrix[0][1] != "" and matrix[0][2] != "" and matrix[1][0] != "" and matrix[1][1] != "" and matrix[1][2] != "" and matrix[2][0] != "" and matrix[2][1] != "" and matrix[2][2] != "": return "NoWinner"
    if __name__ == "__main__":
        pygame.init()
        width, height = 640, 640
        x, y =  pygame.display.Info().current_w, pygame.display.Info().current_h
        if x >= 1920: x_text, x_message = 100, 170
        if x < 1920: x_text, x_message = 55, 150
        screen_width = int((x // 2) - (width // 2))
        screen_height = int((y // 2) - (height // 2))
        os.environ["SDL_VIDEO_WINDOW_POS"] = "%d,%d" % (screen_width, screen_height)
        icon = pygame.image.load("LIB/IMG/icon.ico")
        if platform.system() == "Windows":
            pygame.display.set_icon(icon)
        scorePlayerOne = 0
        scorePlayerTwo = 0
        window = pygame.display.set_mode((width, height), pygame.SWSURFACE | pygame.HWACCEL | pygame.DOUBLEBUF)
        police = pygame.font.SysFont("arial", 30)
        var = False
        def messageWinX():
            message = police.render("LES CROIX ONT GAGNÉ !", False, (255, 255, 255))
            window.blit(message, [x_message, 275])
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(messageTwo, [x_text, 500])
        def messageWinO():
            message = police.render("LES RONDS ONT GAGNÉ !", False, (255, 255, 255))
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(message, [x_message, 275])
            window.blit(messageTwo, [x_text, 500])
        def messageNoWinner():
            message = police.render("MATCH NUL !", False, (255, 255, 255))
            window.blit(message, [230, 300])
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(messageTwo, [x_text, 500])
            
        def caseStart():
            global game, caseAutorisations, player, matrix
            pygame.mouse.set_cursor(*pygame.cursors.broken_x)
            window.fill((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
            display = [10, 220, 430]
            for k in range(len(display)):
                for i in range(len(display)):
                    window.blit(pygame.image.load("LIB/IMG/black.png"), (display[i], display[k]))
            game = True
            player = random.randint(1, 2)
            if player == 1: pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}    Les croix commencent")
            if player == 2: pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}    Les ronds commencent")
            caseAutorisations = [True, True, True, True, True, True, True, True, True]
            matrix = [["", "", ""], ["", "", ""], ["", "", ""]]
            pygame.display.update()
        def mainMenu():
            global var
            def hover(nameImage, posX, posY):
                window.blit(pygame.image.load("LIB/IMG/{}".format(nameImage)), (posX, posY))
                pygame.display.update()
            window.fill((random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
            pygame.display.set_caption("TIC TAC TOE | DÉMARRAGE")
            hover("play.png", 220, 245)
            hover("exit.png", 220, 345)
            play = True
            while play:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        play = False
                        pygame.quit()
                    x_pos, y_pos = pygame.mouse.get_pos()
                    if event.type == pygame.MOUSEMOTION and 220 < x_pos < 420 and 245 < y_pos < 295: hover("play1.png", 220, 245)
                    if event.type == pygame.MOUSEMOTION and 220 < x_pos < 420 and 345 < y_pos < 395: hover("exit1.png", 220, 345)
                    if event.type == pygame.MOUSEMOTION and (0 < x_pos < 220 or 420 < x_pos < 640) and (0 < y_pos < 345 or 395 < y_pos < 640): hover("exit.png", 220, 345)
                    if event.type == pygame.MOUSEMOTION and (0 < x_pos < 220 or 420 < x_pos < 640) and (0 < y_pos < 245 or 295 < y_pos < 640): hover("play.png", 220, 245)
                    if event.type == pygame.MOUSEBUTTONUP:
                        if 220 < x_pos < 420 and 245 < y_pos < 295: 
                            hover("play1.png", 220, 245)
                            caseStart()
                            play, var = False, True
                        if 220 < x_pos < 420 and 345 < y_pos < 395: 
                            hover("exit1.png", 220, 345)
                            play = False
                            pygame.quit()

        mainMenu()
        if var == True:
            while game:
                def function_quit():
                    global game
                    game = False
                    pygame.quit()
                def function_verify():
                    global scorePlayerTwo, scorePlayerOne
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT: function_quit()
                        if event.type == pygame.KEYDOWN:
                            if event.key == K_RETURN:
                                if conditionsWin() == "Owin": scorePlayerTwo += 1
                                if conditionsWin() == "Xwin": scorePlayerOne += 1
                                pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}")
                                caseStart()
                if conditionsWin() == "Owin": window.fill((52, 235, 122)), messageWinO(), pygame.display.update(), function_verify()
                if conditionsWin() == "Xwin": window.fill((52, 235, 122)), messageWinX(), pygame.display.update(), function_verify()
                if conditionsWin() == "NoWinner": window.fill((255, 0, 0)), messageNoWinner(), pygame.display.update(), function_verify()
                def change_player():
                    global player
                    if player == 1: player = 2
                    elif player == 2: player = 1
                def function_game(numberCase, matrixOne, matrixTwo, posX, posY):
                    if player == 1: salut, matrix[matrixOne][matrixTwo] = pygame.image.load("LIB/IMG/croix.png"), "X"
                    if player == 2: salut, matrix[matrixOne][matrixTwo] = pygame.image.load("LIB/IMG/rond.png"), "O"
                    window.blit(salut, (posX, posY))
                    caseAutorisations[numberCase] = False
                    change_player()
                    pygame.display.update()
                if game == True:
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT: function_quit()
                        elif event.type == pygame.MOUSEBUTTONUP:
                            x, y = pygame.mouse.get_pos()
                            pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}")
                            if 10 < x < 210 and 10 < y < 210 and caseAutorisations[0] == True: function_game(0, 0, 0, 10, 10)
                            elif 220 < x < 420 and 10 < y < 210 and caseAutorisations[1] == True: function_game(1, 0, 1, 220, 10)
                            elif 430 < x < 630 and 10 < y < 210 and caseAutorisations[2] == True: function_game(2, 0, 2, 430, 10)
                            elif 10 < x < 210 and 220 < y < 420 and caseAutorisations[3] == True: function_game(3, 1, 0, 10, 220)
                            elif 220 < x < 420 and 220 < y < 420 and caseAutorisations[4] == True: function_game(4, 1, 1, 220, 220)
                            elif 430 < x < 630 and 220 < y < 420 and caseAutorisations[5] == True: function_game(5, 1, 2, 430, 220)
                            elif 10 < x < 210 and 430 < y < 630 and caseAutorisations[6] == True: function_game(6, 2, 0, 10, 430)
                            elif 220 < x < 420 and 430 < y < 630 and caseAutorisations[7] == True: function_game(7, 2, 1, 220, 430)
                            elif 430 < x < 630 and 430 < y < 630 and caseAutorisations[8] == True: function_game(8, 2, 2, 430, 430)
                        else:
                            pygame.display.update()