try:
    import pygame
    import time
    from pygame.locals import *
    import random
except ImportError:
    print("Erreur d'importation des modules supplémentaires ")
except Exception as error:
    print(f"[ERROR] : {error}")
else:
    def conditionsWin():
        # Gagner sur les lignes diagonales
        if matrix[0][0] == "X" and matrix[1][1] == "X" and matrix[2][2] == "X":
            return "Xwin"
        if matrix[0][0] == "O" and matrix[1][1] == "O" and matrix[2][2] == "O":
            return "Owin"
        if matrix[0][2] == "X" and matrix[1][1] == "X" and matrix[2][0] == "X":
            return "Xwin"
        if matrix[0][2] == "O" and matrix[1][1] == "O" and matrix[2][0] == "O":
            return "Owin"

        # Gagner sur les lignes verticales
        if matrix[0][0] == "X" and matrix[1][0] == "X" and matrix[2][0] == "X":
            return "Xwin"
        if matrix[0][1] == "X" and matrix[1][1] == "X" and matrix[2][1] == "X":
            return "Xwin"
        if matrix[0][2] == "X" and matrix[1][2] == "X" and matrix[2][2] == "X":
            return "Xwin"
        if matrix[0][0] == "O" and matrix[1][0] == "O" and matrix[2][0] == "O":
            return "Owin"
        if matrix[0][1] == "O" and matrix[1][1] == "O" and matrix[2][1] == "O":
            return "Owin"
        if matrix[0][2] == "O" and matrix[1][2] == "O" and matrix[2][2] == "O":
            return "Owin"

        # Gagner sur les lignes horizontales
        if matrix[0][0] == "X" and matrix[0][1] == "X" and matrix[0][2] == "X":
            return "Xwin"
        if matrix[1][0] == "X" and matrix[1][1] == "X" and matrix[1][2] == "X":
            return "Xwin"
        if matrix[2][0] == "X" and matrix[2][1] == "X" and matrix[2][2] == "X":
            return "Xwin"

        if matrix[0][0] == "O" and matrix[0][1] == "O" and matrix[0][2] == "O":
            return "Owin"
        if matrix[1][0] == "O" and matrix[1][1] == "O" and matrix[1][2] == "O":
            return "Owin"
        if matrix[2][0] == "O" and matrix[2][1] == "O" and matrix[2][2] == "O":
            return "Owin"

        # Quand il y a match nul
        if matrix[0][0] != "" and matrix[0][1] != "" and matrix[0][2] != "" and matrix[1][0] != "" and matrix[1][1] != "" and matrix[1][2] != "" and matrix[2][0] != "" and matrix[2][1] != "" and matrix[2][2] != "":
            return "NoWinner"
    if __name__ == "__main__":
        pygame.init()
        icon = pygame.image.load("LIB/IMG/icon.ico")
        pygame.display.set_icon(icon)
        scorePlayerOne = 0
        scorePlayerTwo = 0
        window = pygame.display.set_mode((640, 640), pygame.HWSURFACE)
        police = pygame.font.SysFont("arial", 30)

        def messageWinX():
            message = police.render("LES CROIX ONT GAGNÉ !", False, (255, 255, 255))
            window.blit(message, [150, 275])
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(messageTwo, [100, 500])

        def messageWinO():
            message = police.render("LES RONDS ONT GAGNÉ !", False, (255, 255, 255))
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(message, [150, 275])
            window.blit(messageTwo, [100, 500])

        def messageNoWinner():
            message = police.render("MATCH NUL !", False, (255, 255, 255))
            window.blit(message, [230, 300])
            messageTwo = police.render("PRESSEZ ENTRER POUR REJOUER !", False, (0, 0, 0))
            window.blit(messageTwo, [100, 500])
            
        def caseStart():
            global game, caseAutorisations, player, matrix
            window.fill((255, 255, 255))
            caseOne = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseOne, (10, 10))
            caseTwo = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseTwo, (10, 220))
            caseThree = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseThree, (10, 430))
            caseFour = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseFour, (220, 10))
            caseFive = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseFive, (220, 220))
            caseSix = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseSix, (220, 430))
            caseSeven = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseSeven, (430, 10))
            caseEight = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseEight, (430, 220))
            caseNine = pygame.image.load("LIB/IMG/black.png")
            window.blit(caseNine, (430, 430))
            game = True
            player = random.randint(1, 2)
            if player == 1:
                pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}    Les croix commencent")
            if player == 2:
                pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}    Les ronds commencent")
            caseAutorisations = [True, True, True, True, True, True, True, True, True]
            matrix = [["", "", ""], ["", "", ""], ["", "", ""]]
            pygame.display.update()

        caseStart()
        while game:
            def function_quit():
                global game
                game = False
                pygame.quit()
            def function_verify():
                global scorePlayerTwo, scorePlayerOne
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        function_quit()
                    if event.type == pygame.KEYDOWN:
                        if event.key == K_RETURN:
                            if conditionsWin() == "Owin":
                                scorePlayerTwo += 1
                            if conditionsWin() == "Xwin":
                                scorePlayerOne += 1
                            pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}")
                            caseStart()
            if conditionsWin() == "Owin":
                window.fill((56, 202, 5))
                messageWinO()
                pygame.display.update()
                function_verify()
            if conditionsWin() == "Xwin":
                window.fill((56, 202, 5))
                messageWinX()
                pygame.display.update()
                function_verify()
            if conditionsWin() == "NoWinner":
                window.fill((255, 0, 0))
                messageNoWinner()
                pygame.display.update()
                function_verify()
            def change_player():
                global player
                if player == 1:
                    player = 2
                elif player == 2:
                    player = 1
            if game == True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        function_quit()
                    elif event.type == pygame.MOUSEBUTTONUP:
                        x, y = pygame.mouse.get_pos()
                        pygame.display.set_caption(f"TIC TAC TOE    CROIX : {scorePlayerOne}    RONDS : {scorePlayerTwo}")
                        if 10 < x < 210 and 10 < y < 210 and caseAutorisations[0] == True:
                            if player == 1:
                                caseOne = pygame.image.load("LIB/IMG/croix.png")
                                matrix[0][0] = "X"
                            if player == 2:
                                caseOne = pygame.image.load("LIB/IMG/rond.png")
                                matrix[0][0] = "O"
                            window.blit(caseOne, (10, 10))
                            caseAutorisations[0] = False
                            change_player()
                        elif 220 < x < 420 and 10 < y < 210 and caseAutorisations[1] == True:
                            if player == 1:
                                caseTwo = pygame.image.load("LIB/IMG/croix.png")
                                matrix[0][1] = "X"
                            if player == 2:
                                caseTwo = pygame.image.load("LIB/IMG/rond.png")
                                matrix[0][1] = "O"
                            window.blit(caseTwo, (220, 10))
                            caseAutorisations[1] = False
                            change_player()
                        elif 430 < x < 630 and 10 < y < 210 and caseAutorisations[2] == True:
                            if player == 1:
                                caseThree = pygame.image.load("LIB/IMG/croix.png")
                                matrix[0][2] = "X"
                            if player == 2:
                                caseThree = pygame.image.load("LIB/IMG/rond.png")
                                matrix[0][2] = "O"
                            window.blit(caseThree, (430, 10))
                            caseAutorisations[2] = False
                            change_player()
                        elif 10 < x < 210 and 220 < y < 420 and caseAutorisations[3] == True:
                            if player == 1:
                                caseFour = pygame.image.load("LIB/IMG/croix.png")
                                matrix[1][0] = "X"
                            if player == 2:
                                caseFour = pygame.image.load("LIB/IMG/rond.png")
                                matrix[1][0] = "O"
                            window.blit(caseFour, (10, 220))
                            caseAutorisations[3] = False
                            change_player()
                        elif 220 < x < 420 and 220 < y < 420 and caseAutorisations[4] == True:
                            if player == 1:
                                caseFive = pygame.image.load("LIB/IMG/croix.png")
                                matrix[1][1] = "X"
                            if player == 2:
                                caseFive = pygame.image.load("LIB/IMG/rond.png")
                                matrix[1][1] = "O"
                            window.blit(caseFive, (220, 220))
                            caseAutorisations[4] = False
                            change_player()
                        elif 430 < x < 630 and 220 < y < 420 and caseAutorisations[5] == True:
                            if player == 1:
                                caseSix = pygame.image.load("LIB/IMG/croix.png")
                                matrix[1][2] = "X"
                            if player == 2:
                                caseSix = pygame.image.load("LIB/IMG/rond.png")
                                matrix[1][2] = "O"
                            window.blit(caseSix, (430, 220))
                            caseAutorisations[5] = False
                            change_player()
                        elif 10 < x < 210 and 430 < y < 630 and caseAutorisations[6] == True:
                            if player == 1:
                                caseSeven = pygame.image.load("LIB/IMG/croix.png")
                                matrix[2][0] = "X"
                            if player == 2:
                                caseSeven = pygame.image.load("LIB/IMG/rond.png")
                                matrix[2][0] = "O"
                            window.blit(caseSeven, (10, 430))
                            caseAutorisations[6] = False
                            change_player()

                        elif 220 < x < 420 and 430 < y < 630 and caseAutorisations[7] == True:
                            if player == 1:
                                caseEight = pygame.image.load("LIB/IMG/croix.png")
                                matrix[2][1] = "X"
                            if player == 2:
                                caseEight = pygame.image.load("LIB/IMG/rond.png")
                                matrix[2][1] = "O"
                            window.blit(caseEight, (220, 430))
                            caseAutorisations[7] = False
                            change_player()
                        elif 430 < x < 630 and 430 < y < 630 and caseAutorisations[8] == True:
                            if player == 1:
                                caseNine = pygame.image.load("LIB/IMG/croix.png")
                                matrix[2][2] = "X"
                            if player == 2:
                                caseNine = pygame.image.load("LIB/IMG/rond.png")
                                matrix[2][2] = "O"
                            window.blit(caseNine, (430, 430))
                            caseAutorisations[8] = False
                            change_player()
                        pygame.display.update()
                    else:
                        pygame.display.update()
